from distutils.core import setup 

setup(name="getTree",version="1.0",description="get dir tree",author="L",py_modules=['listDir.tree'])
